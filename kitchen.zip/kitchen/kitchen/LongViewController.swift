//
//  LongViewController.swift
//  kitchen
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit
import AVFoundation

class LongViewController: UIViewController {

     var player = AVAudioPlayer()
    
    var totalTime = 0
    var countdownTimer:Timer!
    var isTimerRunning = false
    
    
    @IBOutlet weak var mTimer: UITextField!
    
    
    @IBOutlet weak var sTimer: UITextField!
    
    @IBOutlet weak var hTimer: UITextField!
    
    
    
    @IBAction func fiveHour(_ sender: UIButton) {
        totalTime = 18000
        startTimer()
    }
    
    @IBAction func fourAndHalfHour(_ sender: UIButton) {
        totalTime = 16200
        startTimer()
    }
    
    @IBAction func fourHour(_ sender: UIButton) {
        totalTime = 14400
        startTimer()
    }
    
    @IBAction func threeAndHalfHour(_ sender: UIButton) {
        totalTime = 12600
        startTimer()
    }
    
    @IBAction func threeHour(_ sender: UIButton) {
        totalTime = 10800
        startTimer()
    }
    @IBAction func twoAndHalfHour(_ sender: UIButton) {
        totalTime = 9000
        startTimer()
    }
    
    @IBAction func twoHour(_ sender: UIButton) {
        totalTime = 7200
        startTimer()
    }
    @IBAction func oneAndHalfHour(_ sender: UIButton) {
        totalTime = 5400
        startTimer()
    }
    
    @IBAction func oneHour(_ sender: UIButton) {
        totalTime = 3600
        startTimer()
    }
    
    
    
    
    @IBAction func stop(_ sender: UIButton) {
        endTimer()
        timeToZero()
    }
    
    
    func timeToZero(){
        
        mTimer.text = "00"
        sTimer.text = "00"
        hTimer.text = "00"
    }
    func startTimer() {
        isTimerRunning = true
        countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        //countdownTimer = Timer.init(timeInterval: 1, repeats: true, block: { (_ ) in
        //updateTime()
    }
    //)
    
    @objc func updateTime() {
        
        //if totalTime != -1 {setValueToFields()}
        if totalTime != -1 {
            setValueToFields()
            totalTime -= 1
            
        } else {
              player.play()
            endTimer()
        }
    }
    
    func endTimer() {
        //sound()
        countdownTimer.invalidate()
        isTimerRunning = false
        
        // timeToZero()
        
    }
    func setValueToFields(){
        hTimer.text = String(format: "%02d", totalTime/3600)
        mTimer.text = String(format: "%02d", (totalTime%3600)/60)
        sTimer.text = String(format: "%02d", (totalTime%3600)%60)
    }
    
    
    
    override func viewDidLoad() {
        do{
            let audioPath = Bundle.main.path(forResource: "bell", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
            
        }catch{
            print("Audio is unavailable")
        }
        super.viewDidLoad()
        timeToZero()
        
    }
    
    
    

}
