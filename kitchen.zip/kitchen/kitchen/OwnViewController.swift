//
//  OwnViewController.swift
//  kitchen
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit
import AVFoundation
class OwnViewController: UIViewController {

     var player = AVAudioPlayer()
    
    override func viewDidLoad() {
        do{
            let audioPath = Bundle.main.path(forResource: "bell", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
            
        }catch{
            print("Audio is unavailable")
        }
        super.viewDidLoad()
        timeToZero()
     //  sTimer.text = "dd"
}
    
    var totalTime = 0
    var countdownTimer:Timer!
    var isTimerRunning = false
    //var isStopped = false
    
    @IBOutlet weak var hTimer: UITextField!
    
    @IBOutlet weak var mTimer: UITextField!
    
    @IBOutlet weak var sTimer: UITextField!
    
    
    @IBAction func start(_ sender: UIButton) {
     
        totalTime = Int(hTimer.text!)!*3600 + Int(mTimer.text!)!*60 + Int(sTimer.text!)!
    
        startTimer()
    }
    @IBAction func stop(_ sender: UIButton) {
        endTimer()
        timeToZero()
    }
    func startTimer(){
    isTimerRunning = true
    countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        
    }
    @objc func updateTime() {

        if totalTime != -1 {
            setValueToFields()
            totalTime -= 1
          
            
        } else {
            player.play()
            endTimer()
        }
    }
    
    func endTimer() {
    
        countdownTimer.invalidate()
        isTimerRunning = false
     
        
    }
    func setValueToFields(){
        hTimer.text = String(format: "%02d", totalTime/3600)
        mTimer.text = String(format: "%02d", (totalTime%3600)/60)
        sTimer.text = String(format: "%02d", (totalTime%3600)%60)
    }
    
    
    func timeToZero(){
        
        mTimer.text = "00"
        sTimer.text = "00"
        hTimer.text = "00"
    }
}
