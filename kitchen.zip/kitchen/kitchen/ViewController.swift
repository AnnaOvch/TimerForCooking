//
//  ViewController.swift
//  kitchen
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
}

