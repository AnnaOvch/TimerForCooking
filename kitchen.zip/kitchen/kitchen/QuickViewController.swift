//
//  QuickViewController.swift
//  kitchen
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit
import AVFoundation
class QuickViewController: UIViewController {
    var player = AVAudioPlayer()
    
var totalTime = 0
var countdownTimer:Timer!
var isTimerRunning = false
 
 
    @IBOutlet weak var mTimer: UITextField!
    

    @IBOutlet weak var sTimer: UITextField!
    
    
   
    
    @IBAction func oneMinute(_ sender: UIButton) {
        totalTime = 60
        startTimer()
    }
    
    @IBAction func twoMinute(_ sender: UIButton) {
        totalTime = 120
        startTimer()
    }
    
    @IBAction func fiveMinute(_ sender: UIButton) {
        totalTime = 300
        startTimer()
    }
    
    @IBAction func sevenMinute(_ sender: UIButton) {
        totalTime = 420
        startTimer()
    }
    
    @IBAction func tenMinute(_ sender: UIButton) {
        totalTime = 600
        startTimer()
    }
    @IBAction func twelveMinute(_ sender: UIButton) {
        totalTime = 720
        startTimer()
    }
    
    @IBAction func fifteenMinute(_ sender: UIButton) {
        totalTime = 900
        startTimer()
    }
    @IBAction func seventeenMinute(_ sender: UIButton) {
        totalTime = 1020
        startTimer()
    }
    
    @IBAction func twentyMinute(_ sender: UIButton) {
        totalTime = 1200
        startTimer()
    }
    
    
  
    
    @IBAction func stop(_ sender: UIButton) {
        endTimer()
        timeToZero()
    }
    
    
    func timeToZero(){
       
        mTimer.text = "00"
        sTimer.text = "00"
    }
    func startTimer() {
        isTimerRunning = true
        countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        //countdownTimer = Timer.init(timeInterval: 1, repeats: true, block: { (_ ) in
            //updateTime()
        }
    //)
    
    @objc func updateTime() {
        
        //if totalTime != -1 {setValueToFields()}
        if totalTime != -1 {
            setValueToFields()
            totalTime -= 1
            
        } else {
            player.play()
            endTimer()
        }
    }
    
    func endTimer() {
        //sound()
        countdownTimer.invalidate()
        isTimerRunning = false
        
       // timeToZero()
        
    }
    func setValueToFields(){
       // hTimer.text = String(format: "%02d", totalTime/3600)
        mTimer.text = String(format: "%02d", (totalTime%3600)/60)
        sTimer.text = String(format: "%02d", (totalTime%3600)%60)
    }
    
    
        
    override func viewDidLoad() {
        do{
            let audioPath = Bundle.main.path(forResource: "bell", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
            
        }catch{
            print("Audio is unavailable")
        }
        super.viewDidLoad()
        timeToZero()
        
    }
    
    
    
   
   

}
