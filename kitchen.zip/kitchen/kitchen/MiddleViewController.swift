//
//  MiddleViewController.swift
//  kitchen
//
//  Created by Anna Ovchinnikova on 11/12/18.
//  Copyright © 2018 Anna Ovchinnikova. All rights reserved.
//

import UIKit
import AVFoundation
class MiddleViewController: UIViewController {
 var player = AVAudioPlayer()
  

   
        
        var totalTime = 0
        var countdownTimer:Timer!
        var isTimerRunning = false
        
        
        @IBOutlet weak var mTimer: UITextField!
        
        
        @IBOutlet weak var sTimer: UITextField!
        
        @IBOutlet weak var hTimer: UITextField!
    
        
        
        @IBAction func twentyMinute(_ sender: UIButton) {
            totalTime = 60*20
            startTimer()
        }
        
        @IBAction func twentyFiveMinute(_ sender: UIButton) {
            totalTime = 60*25
            startTimer()
        }
        
        @IBAction func thirtyMinute(_ sender: UIButton) {
            totalTime = 30*60
            startTimer()
        }
        
        @IBAction func thirtyFiveMinute(_ sender: UIButton) {
            totalTime = 35*60
            startTimer()
        }
        
        @IBAction func fourtyMinute(_ sender: UIButton) {
            totalTime =  60*40
            startTimer()
        }
        @IBAction func fourtyFiveMinute(_ sender: UIButton) {
            totalTime = 45*60
            startTimer()
        }
        
        @IBAction func fiftyMinute(_ sender: UIButton) {
            totalTime = 50*60
            startTimer()
        }
        @IBAction func fiftyFiveMinute(_ sender: UIButton) {
            totalTime = 55*60
            startTimer()
        }
        
        @IBAction func oneHour(_ sender: UIButton) {
            totalTime = 3600
            startTimer()
        }
        
        
        
        
        @IBAction func stop(_ sender: UIButton) {
            endTimer()
            timeToZero()
        }
        
        
        func timeToZero(){
            
            mTimer.text = "00"
            sTimer.text = "00"
            hTimer.text = "00"
        }
        func startTimer() {
            isTimerRunning = true
            countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
            //countdownTimer = Timer.init(timeInterval: 1, repeats: true, block: { (_ ) in
            //updateTime()
        }
        //)
        
        @objc func updateTime() {
            
            //if totalTime != -1 {setValueToFields()}
            if totalTime != -1 {
                setValueToFields()
                totalTime -= 1
                
            } else {
                  player.play()
                endTimer()
            }
        }
        
        func endTimer() {
            //sound()
            countdownTimer.invalidate()
            isTimerRunning = false
            
            // timeToZero()
            
        }
        func setValueToFields(){
             hTimer.text = String(format: "%02d", totalTime/3600)
            mTimer.text = String(format: "%02d", (totalTime%3600)/60)
            sTimer.text = String(format: "%02d", (totalTime%3600)%60)
        }
        
        
        
        override func viewDidLoad() {
            do{
                let audioPath = Bundle.main.path(forResource: "bell", ofType: "mp3")
                try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
                
            }catch{
                print("Audio is unavailable")
            }
            super.viewDidLoad()
            timeToZero()
            
        }
        
        
        
        
        
        
    }

   

